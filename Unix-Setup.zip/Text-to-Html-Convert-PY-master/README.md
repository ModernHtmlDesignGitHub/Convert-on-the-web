# Text to Html Converter Python Script
Convert text to a basic .html file. Works on Windows, macOS, and Linux!
Saves file to your desktop!
